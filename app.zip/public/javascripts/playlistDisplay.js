function PLdisplay(list){
  var curr;
  if(list._head != null)
   {
     var printPL="";
    curr = list._head;
    while( curr ) {
      printPL+=`<div class="songlist"><img src="${curr.data.thumbNail.default.url}" style="width:30px; height:30px; float:left;" > <span style="display:block;">${curr.data.artist}</span><span style="display:block;">${curr.data.title}</span> </div>`
      curr = curr.next;
    }
    document.getElementById("Playlist").innerHTML=printPL;
  }
}
