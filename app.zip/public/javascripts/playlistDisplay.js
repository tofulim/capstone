function PLdisplay(list){
  var curr;
  var num;
  var printPL="";
  if(list._head != null)
   {
    curr = list._head;
    while( curr ) {
      printPL+=`<div class="songlist" onclick="onclickPlaylist(\'${curr.data.VID}\')"><img src="${curr.data.thumbNail.default.url}" style="width:30px; height:30px; float:left;" > <span style="display:block;">${curr.data.artist}</span><span style="display:block;">${curr.data.title}</span><button type="button" onclick="onclickRemoveBtn(\'${curr.data.VID}\');">삭제</button></div>`;
      curr = curr.next;
    }
    document.getElementById("Playlist").innerHTML=printPL;
  }
  else {
    document.getElementById("Playlist").innerHTML=printPL;
  }
}
