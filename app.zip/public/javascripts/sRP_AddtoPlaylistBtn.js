function onclickAddBtn(index){
  list.append(confirmedData[index]);
  console.log(list);
  PLdisplay(list);
}
