function onclickSearch(){ //검색창에 입력한 값
  $.ajax({
            url : '/main',
            type : 'post',
            success: function(data) {
                $('#searchResultPage').html(data);
            },
                error: function() {
                $('#searchResultPage').text('페이지 점검중 입니다.');
            }
        });
  var ss=document.getElementById("searchResultPage");
  var input = document.getElementById("inputText").value; //검색창에 입력한 값을 input으로 받아옴
  var optionParams={
    q: `${input}+audio`,
    part:"snippet",
    key:"AIzaSyBHL4BgbHvV7pb3fiYhruUn9zxqET2Yclo",
    maxResults:10
   };
   var url="https://www.googleapis.com/youtube/v3/search?";
   for(var option in optionParams){
    url+=option+"="+optionParams[option]+"&";
   }
   url=url.substr(0, url.length-1);

   var ss=document.getElementById("searchResultPage");
   let body;
  var xhr = new XMLHttpRequest();
    xhr.open("GET" , encodeURI(url) , true);
    xhr.onreadystatechange = function() {
          if(xhr.readyState == 4 && xhr.status == 200)
          {
              var searchResultHTML;
              body=xhr.responseText;
              var data=JSON.parse(body).items;
                for(var content in data){
              		//youtube downloader에 videoId 넘기면 됨.
              		var body2=(data[content].snippet.title+" : "+data[content].id.videoId);
              		searchResultHTML += `<h4>${body2}</h4>`;
              	 }
          }
                ss.innerHTML=searchResultHTML;
                //                              현재 searchResultPage로 넘어갔다가 이게 ss.inner로 했기때문에
                // main.ejs꺼로 정보를 덧씌움 , 글로 가게하고 body를 전역 객체로 전달해주거나 여튼 result.ejs로 전달해줘서
                // 거기서 버튼들이랑 같이 구현하면 됨
        }
          xhr.send();
}
