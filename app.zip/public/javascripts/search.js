function onclickSearch(){ //검색창에 입력한 값
  $.ajax({
            url : '../../views/capstone/searchResultPage.ejs',
            type : 'post',
            success: function(data) {
                $('#searchResultPage').html(data);
            },
                error: function() {
                $('#searchResultPage').text('페이지 점검중 입니다.');
            }
        });
  var ss=document.getElementById("searchResultPage");
  var input = document.getElementById("inputText").value; //검색창에 입력한 값을 input으로 받아옴
  var optionParams={
    q: `${input}+audio`,
    part:"snippet",
    key:"AIzaSyBHL4BgbHvV7pb3fiYhruUn9zxqET2Yclo",
    maxResults:10
   };
   var url="https://www.googleapis.com/youtube/v3/search?";
   for(var option in optionParams){
    url+=option+"="+optionParams[option]+"&";
   }
   url=url.substr(0, url.length-1);

   var ss=document.getElementById("searchResultPage");
   let body;
  var xhr = new XMLHttpRequest();
    xhr.open("GET" , encodeURI(url) , true);
    xhr.onreadystatechange = function() {
        if(xhr.readyState == 4 && xhr.status == 200)
        {
            var resultNum=optionParams.maxResults;
            var searchResultHTML;
            body=xhr.responseText;
            for(var i=0;i<resultNum;i++){
              //채널 id랑 비교해서 썸네일 따야함
              if(body.items[i]);
            }

            ss.innerHTML = `${body}`;
        }
    }
    xhr.send();


}
