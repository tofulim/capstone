var usr_name;
var kakao_get_name = function() {
  Kakao.init('e965922752dd0e459d202be15719070e');
  Kakao.API.request({
    url: '/v2/user/me',
    success: function(res){
      usr_name=res.properties.nickname;
      document.getElementById("userName").innerHTML=`${usr_name}님 SSS에 오신 것을 환영합니다`;
    },
    fail: function(error){
      alert(JSON.stringify(error));
    }
  });
};
window.sessionStorage.setItem('name', name);
let dataName = sessionStorage.getItem('name');
