function reloadMain(){
       $("#reloadSection").load(window.location.href + "#reloadSection");
}
